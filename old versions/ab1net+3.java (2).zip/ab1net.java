import java.util.Scanner;
import java.lang.Math;
/**
 * Builds an A-B-1 Network to solve problems like OR, AND, and XOR.
 * Can run based of inputed weights or train with random weights using gradient descent minimization. 
 * 1) It configures the parameters and variables to set the structure, mode, and values of the network
 * 2) Prints out the parameters for the user to see what it received
 * 3) Allocate proper memory for arrays depending on if running or training 
 * 4) Fill in the arrays of the truth table and weights depending on testing or running and training type.
 *    The network runs feedforward. From an input layer to a hidden layer to an output layer
 * 5) If running, it will find output value. If training, use gradient descent to find error minimized output value
 * 6) Report the output results 
 *  
 * @author 24aeliyag
 * @version September 19 2023
 */
public class ab1net 
{
   private static boolean training;
   
   private static double randomLow, randomHigh;

   private static int  numInputNodes, numHiddenNodes, numTrainingCases;
   private static int  numHiddenWeights, numOutputWeights;
   private static int  maxIterations, iterationsReached, printIterationNum;
   
   private static double[] thetaj, thetai, t;
   private static double[] a, h, f;     
      
   private static double lambda, errorThreshold, currentError;
   private static double psi0; 
   
   private static double[][] truthTable, wkj, wji, deltaWkj, deltaWji;
   
   
   /**
    * Sets variables to help construct the A-B-1 structure and mode
    */
   public static void configParams()
   {
      training = true; 
      
      randomLow = -1.5; 
      randomHigh = 1.5; 
   
      numInputNodes = 2; 
      numHiddenNodes = 4; 


      numHiddenWeights = numHiddenNodes*numInputNodes; 
      numOutputWeights = numHiddenNodes;


      lambda = 0.3;
      maxIterations = 100000;
      errorThreshold = 0.002;
      printIterationNum = 5000;
      

      numTrainingCases = 4;
      iterationsReached = 0;
      
   }// public static void configParams()
   
   /**
    * Prints out the variables to user to inform of network configuration.
    * If training, it also outputs training parameters
    */
   public static void echoConfigParams()
   {
      System.out.println("---------------------------------------------------------");
      System.out.println("ECHOING CONFIGURATION PARAMETERS");
      System.out.println();
      System.out.println("    Network Configuration= " + numInputNodes + "-" + numHiddenNodes + "-1");          //Network configuration
      if (training)                                                                                             //only if training:
      {
         System.out.println("    Runtime Trainng Parameters: ");                                                                           
         System.out.println("        Random number range: (" + randomLow + "," + randomHigh + ")");         
         System.out.println("        Max iterations: " + maxIterations);                           
         System.out.println("        Error threshold: " + errorThreshold);                              
         System.out.println("        Lambda value: " + lambda);                               
        
      } // if (training) 
   }//public static void echoConfigParams()
   
   
   /**
    * Defining and dimensioning arrays dependent on whether the program is training or running
    */
   public static void allocateMemory()
   {
      a = new double[numTrainingCases];
      h = new double[numHiddenNodes];
      f = new double[1];


      truthTable = new double[numTrainingCases][numInputNodes];

      wkj = new double[numInputNodes][numHiddenNodes];
      wji = new double[numHiddenNodes][1];

      thetaj = new double[numHiddenNodes];
      thetai = new double[1];

      if (training)
      {
         deltaWkj = new double[numInputNodes][numHiddenNodes];
         deltaWji = new double[numHiddenNodes][1];
         t = new double[numTrainingCases];
      } // if (training)
   
   }// public static void allocateMemory()
   
   /**
    * Assigns values for necessary arrays dependent on if training or running. 
    * Fills in the truth table arrays with proper values for inputs. 
    * If the network is training, it will find random weight values and fill the expected outputs.
    * If the network is running, it will take weight values from the user. 
    * 
    */
   public static void populateArrays()
   { 
      fillTruthTable();


      if (training)                               //Fills in the weights dependent on training mode
      {
         fillExpectedOutputs();
          
         for (int k = 0; k < numInputNodes; k++)                   
         {
            for (int j = 0; j < numHiddenNodes; j++)
            {
               wkj[k][j] = randomValue();         //randomly generate values for Wkj weights
            }
         }
         
         for (int j = 0; j < numInputNodes; j++)
         {
            wji[j][0] = randomValue();           //randomly generate values for Wji weights           
         } 
      } // if (training)
      else
      {
         Scanner take = new Scanner(System.in);  
    
         for (int k = 0; k < numInputNodes; k++)
         {
            for (int j = 0; j < numHiddenNodes; j++)
            {
               System.out.println("Please put in a value for inner W" + k + j);  
               wkj[k][j] = take.nextDouble();                                  // Takes in inputs for the Wkj weights
            }
         }
       
         for (int j = 0; j < numInputNodes; j++)
         {
            System.out.println("Please put in a value for outer W" + j + 1);   // Takes in inputs for the Wji weights
            wji[j][0] = take.nextDouble();   
             
         } 
      }// if (training)... else

   }// public static void populateArrays()

   /**
    * Sets the outputs to train the network on.
    */
   public static void fillExpectedOutputs()
   {
      t[0] = 0.0;     
      t[1] = 1.0; 
      t[2] = 1.0; 
      t[3] = 0.0; 
   }

   /**
    * Assigns the a0 and a1 values in the truth tables
    */
   public static void fillTruthTable()
   {
      truthTable[0][0] = 0.0;      
      truthTable[0][1] = 0.0;
      truthTable[1][0] = 0.0;
      truthTable[1][1] = 1.0;
      truthTable[2][0] = 1.0;
      truthTable[2][1] = 0.0;
      truthTable[3][0] = 1.0;
      truthTable[3][1] = 1.0;
   } // public static void fillTruthTable()

   /**
    * Randomly generates a value based on a preset range
    * @return randomly generated number
    */
   public static double randomValue()
   {
      return (double)(Math.random() * (randomHigh - randomLow)) + randomLow;    
   }
   
   /**
    * If the training variable is true, it will run and train the  feedforward A-B-1 Network 
    * using gradient descent minimization stopping only if an error threshold or maximum iteration has been met.
    * If not, it will find the output based on predetermined weights
    */
   public static void trainOrRun()
   {
      if (!training) 
      {
         for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
         {
            findNetworkOutput(numTraining);                                               //running the network on inputed weights
         }
      } //if (!training) 
      else
      {
         System.out.println("------------------------------------------");
         System.out.println("Training Network: ");
         findNetworkError();              
         while (currentError > errorThreshold && iterationsReached < maxIterations)       //Determines if another round of gradient descent needs to be found
         {
            for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)      //Loops through each training case
            {
               findNetworkOutput(numTraining);
               
               calcDeltaWOuputLayer(numTraining);                                         //Finds the deltaWji
               calcDeltaWHiddenLayer();                                                   //Finds the deltaWjk
              
               addDeltaW();                                                               //Adds the deltaWs to the weights
              
         } //for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
            if (iterationsReached % printIterationNum == 0.0)
            {
               System.out.println();    
               System.out.println("   Error: " + currentError );
               System.out.println("   Training Iteration: " + iterationsReached);
            }
            findNetworkError();  
            iterationsReached++;
         } //while (currentError > errorThreshold && iterationsReached < maxIterations) 
      } //if (!training)... else 
   } //public static void trainOrRun()
   
   /**
    * Finds the deltaW for the wj0, weights connecting the hidden layer to the output layer.
    */
   public static void calcDeltaWOuputLayer(int ii)
   {
      double lowerCaseOmega = t[ii] - f[0];
      psi0 = lowerCaseOmega * activationFunctionDeriv(thetai[0]);

      for (int j = 0; j < numHiddenNodes; j++)
      {
         double partialDeriv = -h[j] * psi0; 
         deltaWji[j][0] = -lambda * partialDeriv;
      }  
   }
   
   /**
    * Finds the deltaW for the wkj, weights connecting the input to hidden layer.
    */
   public static void calcDeltaWHiddenLayer()
   {
      for (int j = 0; j < numHiddenNodes; j++) 
      {
         double upperCaseOmegaJ = psi0 * wji[j][0];   
         double upperCasePsiJ = upperCaseOmegaJ * activationFunctionDeriv(thetaj[j]);
         for (int k = 0; k < numInputNodes; k++)
         {
            double partialDeriv = -a[k] * upperCasePsiJ;
            deltaWkj[k][j] = -lambda * partialDeriv;   
         }
      } //for (int j = 0; j < numHiddenNodes; j++) 
     
   } //public static void calcDeltaWHiddenLayer()
   
   /**
    * Adds delta weight values to the current weights for wkj and wji
    */
   public static void addDeltaW()
   {
      for (int k = 0; k < numInputNodes; k++)
      {
         for (int j = 0; j < numHiddenNodes; j++)
         {
            wkj[k][j] += deltaWkj[k][j];             //adding deltaWjk for weights connecting the input and hidden layer
         }
      }
   
      for (int j = 0; j < numHiddenNodes; j++)
      {
         wji[j][0] += deltaWji[j][0];                //adding deltaWji for weights connecting the hidden and output layer
      }  
   } //public static void addDeltaW()
   
   /**
    * Runs through each test case to find the total error for the network
    */
   public static void findNetworkError()
   {
      currentError = 0.0;
      for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      {
         findNetworkOutput(numTraining);
         double lowerCaseOmega = t[numTraining] - f[0];
         currentError += lowerCaseOmega*lowerCaseOmega;
      }
      
      currentError *= 0.5;
   } //public static void findNetworkError()
   
   
   /**
     * Takes in a test case to find the proper inputs. Then, solves the hidden layer values and output value.
     * Solves using feedforward passage.   
     * Saves the theta values to be used in the gradient descent minimization.
     * @param testCase  decides the proper inputs
     */
   public static void findNetworkOutput(int testCase)
   {
      for (int k = 0; k < numInputNodes; k++)
      {
         a[k] = truthTable[testCase][k];                 //fills in input layer Ak
      }
      for (int j = 0; j < numHiddenNodes; j++)
      {
         thetaj[j] = 0;                                  //reset
   
         for (int k = 0; k < numInputNodes; k++)
         {
            thetaj[j] += wkj[k][j] * a[k];               //calculate thetaj
         }   
         
         h[j] = activationFunction(thetaj[j]);           //finds and fills in the hj layer     
      } //for (int j = 0; j < numHiddenNodes; j++)

      thetai[0] = 0;   
      for (int j = 0; j < numHiddenNodes; j++)
      {
         thetai[0] += wji[j][0] * h[j];

      }
      f[0] = activationFunction(thetai[0]);              //calculate the output value

   } //public static void findNetWorkOutput(int testCase)

   /**
    * Passes the input through the threshold function
    * @param x what will be passed through the function
    * @return  output of the function
    */
   public static double activationFunction(double x)
   {
      return 1.0 / (1.0 + Math.exp(-x));
   }
   
   /**
    * Passes the input through the derivative of the activation function   
    * @param x  the input
    * @return  derivative output
    */
   public static double activationFunctionDeriv(double x)
   {
      double activationFunctionResult = activationFunction(x);
      return activationFunctionResult * (1.0 - activationFunctionResult);
   }  
    
      
   /**
    * Prints out a truth table with output values found by the A-B-1 network 
    * If training, provides explanation as to why training stopped with end
    * error and iteration count. 
    */
   public static void reportResults()
   {
      System.out.println("--------------------------------------------------------------------");
      System.out.println("Reporting Results:");
      System.out.println();
        
      if (training)
      {
         System.out.println("   Training Exit Information:");              
         if (currentError <= errorThreshold)                                         //determines if stopped by reaching the error threshold
         {
            System.out.println("      Stopped because network reached error threshold");
         }
         if (iterationsReached >= maxIterations)                                     //determines if stopped by reaching the max iterations
         {
            System.out.println("      Stopped because network reached max iterations");
         }
            
         System.out.println();
         System.out.println("   Total Error Reached: " + currentError); 
         System.out.println("   Total iterations reached: "+ iterationsReached);
      } //if (training)
      
      System.out.println();
      System.out.println("    --a0----a1-----F--");
      System.out.println("    ------------------");
      
      for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      {
         System.out.print("    |");
         for (int k = 0 ; k < numInputNodes; k++)
         {
            System.out.print(" " + truthTable[numTraining][k] + " |");    //Prints out the truth table
            findNetworkOutput(numTraining);                                                    
         }
         System.out.print(f[0]);                                          //Prints out the output values
         System.out.println();             
         
      } //for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
         
      System.out.println("    --------------------");
   } //public static void reportResults()
   
   
   /**
    * Starts by setting variables and allocating proper space. Then, continues by populating the arrays. 
    * The network either runs or trains based on a set variable and the reports are output either at
    * the end of running or until a cuttoff has been passed for training. 
    * @param args
    */
   public static void main(String[] args) 
   {
      configParams();
      echoConfigParams();
      allocateMemory();
      populateArrays();
      trainOrRun();
      reportResults();
   } //public static void main(String[] args) 
   
} //public static void configParams()
