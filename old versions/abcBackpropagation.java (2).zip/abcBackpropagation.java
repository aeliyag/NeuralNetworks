import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.Math;
/**
 * Builds an A-B-C Network to solve problems like OR, AND, and XOR.
 * Performs based of set configurations from a .txt file
 * It uses backpropagation to train the model. 
 * 1) It configures the parameters and variables to set the structure, mode, and values of the network
 * 2) Prints out the parameters for the user to see what it received
 * 3) Allocates proper memory for arrays depending on if running or training 
 * 4) Fills in the arrays of the truth table and weights depending on testing or running and training type.
 * The network runs feedforward. From an input layer to a hidden layer to an output layer
 * 5) If running, it will find output value. If training, it will time the process and use backpropagation to train the network.
 * 6) Report the output results and saves the weights.
 *  
 *  
 *  
 *  Method header table of contents: 
 *  
 *      public static void configParams()
 *      public static void readControlFile()
 *      public static void echoConfigParams()
 *      public static void allocateMemory()
 *      public static void populateArrays()
 *      public static void fillTrainingWeights()
 *      public static void loadWeights()
 *      public static void saveWeights()
 *      public static void fillTruthTableTraining()
 *      public static void fillTruthTableRunning()
 *      public static double randomValue()
 *      public static void trainOrRun()
 *      public static void trainNetwork(int ti)
 *      public static void findNetworkAverageError()
 *      public static void findNetworkOutputRunning(int testCase)
 *      public static void findNetworkOutputTraining(int testCase)
 *      public static double activationFunction(double x)
 *      public static double sigmoidFunction(double x)
 *      public static double activationFunctionDeriv(double x)
 *      public static double sigmoidDeriv(double x)
 *      public static void reportResults()
 *      public static void main(String[] args)
 *      
 *  
 *  
 *  
 * @author Aeliya Grover
 * @version October 05 2023
 */
public class abcBackpropagation 
{
   private static boolean training;
   
   private static String weightPathway, weightfileName;
   
   private static double randomLow, randomHigh;

   private static int  numInputNodes, numHiddenNodes, numOutputNodes, numTrainingCases;
   private static int  numHiddenWeights, numOutputWeights;
   private static int  maxIterations, iterationsReached, printIterationNum;
   
   private static double[] thetaj, thetai;
   private static double[] a, h, f;     
      
   private static double lambda, errorThreshold, totalError, currentAverageError, partialDeriv;
   private static double upperCasePsiJ, upperCaseOmegaJ;
   private static double thetaJ, thetaI;
   private static double[] psiI; 
   
   private static double[][] truthTable, wkj, wji, deltaWkj, deltaWji, t, lowerCaseOmega;
   
   private static double startTime, endTime, totalTime;

   private static File controlFile; 

   /**
    * Sets variables to help construct the A-B-C structure, parameters, and mode
    */
   public static void configParams() throws Exception
   {   
      weightPathway = "/Users/24aeliyag/Desktop/Programming Projects/Neural Networks/weights.txt";
      weightfileName = "weights.txt";
      controlFile = new File ("/Users/24aeliyag/Desktop/Programming Projects/Neural Networks/ControlFile.txt");
      
      readControlFile();    // Sets variables that are read through .txt file
      iterationsReached = 0;

      numHiddenWeights = numHiddenNodes * numInputNodes; 
      numOutputWeights = numHiddenNodes;
   } // public static void configParams()
   
   /**
    * Uses values from the control file to fill in network structure, parameter, and mode.
    * The .txt file must match up to the specific format in order for values to be transfered correctly.
    */
   public static void readControlFile() throws Exception 
   {
      Scanner controlScan = new Scanner(controlFile); 
      
      training = controlScan.nextBoolean();
      randomLow = controlScan.nextDouble(); 
      randomHigh = controlScan.nextDouble(); 
   
      numInputNodes = controlScan.nextInt(); 
      numHiddenNodes = controlScan.nextInt(); 
      numOutputNodes = controlScan.nextInt(); 
      
      numTrainingCases = controlScan.nextInt();
      
      lambda = controlScan.nextDouble();
      maxIterations = controlScan.nextInt();
      errorThreshold = controlScan.nextDouble();
      printIterationNum = controlScan.nextInt();
   } // public static void readControlFile()
   
   /**
    * Prints out the variables to user, informing of network configuration.
    * If training, it also outputs training parameters
    */
   public static void echoConfigParams()
   {
      System.out.println("---------------------------------------------------------");
      System.out.println("ECHOING CONFIGURATION PARAMETERS");
      System.out.println();
      System.out.println("    Network Configuration = " + numInputNodes + "-" + numHiddenNodes + "-" + numOutputNodes); 
     
      if (training)    // Only if training:
      {
         System.out.println("    Runtime Trainng Parameters: ");                                                                           
         System.out.println("        Random number range: (" + randomLow + "," + randomHigh + ")");         
         System.out.println("        Max iterations: " + maxIterations);                           
         System.out.println("        Error threshold: " + errorThreshold);                              
         System.out.println("        Lambda value: " + lambda);                               
        
      } // if (training) 
   } // public static void echoConfigParams()
   
   /**
    * Defining and dimensioning arrays dependent on whether the program is training or running
    */
   public static void allocateMemory()
   {
      a = new double[numInputNodes];
      h = new double[numHiddenNodes];
      f = new double[numOutputNodes];

      truthTable = new double[numTrainingCases][numInputNodes];

      wkj = new double[numInputNodes][numHiddenNodes];
      wji = new double[numHiddenNodes][numOutputNodes];

      if (training)  
      {
         lowerCaseOmega = new double[numTrainingCases][numOutputNodes];
         deltaWkj = new double[numInputNodes][numHiddenNodes];
         deltaWji = new double[numHiddenNodes][numOutputNodes];
         t = new double[numTrainingCases][numOutputNodes];
         psiI = new double[numOutputNodes];
         thetaj = new double[numHiddenNodes];
         thetai = new double[numOutputNodes];
      } // if (training)
   } // public static void allocateMemory()
   
   /**
    * Assigns values for necessary arrays dependent on if training or running. 
    * Fills in the truth table arrays with proper values for inputs. If training, fills out the expected outputs.
    * If the network is training, it will find random weight values and fill the expected outputs.
    * If the network is running, it requires weight values from the user through a .txt file. 
    */
   public static void populateArrays() throws Exception
   { 
      if (training)             // Fills in the weights dependent on training mode
      {
         fillTruthTableTraining();
         fillTrainingWeights();
      } // if (training)
      else
      {
         fillTruthTableRunning();
         loadWeights();
      } // if (training)... else
   } // public static void populateArrays()
  
   /*
    * Generates weights using a random number generator to start training the network.
    */
   public static void fillTrainingWeights()
   {
      for (int k = 0; k < numInputNodes; k++)                   
      {
        
         for (int j = 0; j < numHiddenNodes; j++)
         {
            wkj[k][j] = randomValue();       // Randomly generate values for Wkj weights
         }
         
      } // for (int k = 0; k < numInputNodes; k++)  
      
      for (int j = 0; j < numHiddenNodes; j++)
      {
        
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            wji[j][ii] = randomValue();      // Randomly generate values for Wji weights  
         }
         
      } 
   } // public static void fillTrainingWeights()
   
   /*
    * Sets the weights for the network by reading a txt file. 
    * The .txt is required to first fill in the weights that connect the input layer to hidden layer.
    * The order of the weights file must be constant to match the method.
    * It will then fill the weights that connect the hidden layer to the output layer. 
    * Will throw an error for .txt file if it isn't linked properly. 
    */
   public static void loadWeights() throws Exception
   {
      File file = new File(weightPathway); 
      Scanner scan = new Scanner(file); 
      
      for (int k = 0; k < numInputNodes; k++)
      {
         
         for (int j = 0; j < numHiddenNodes; j++)
         {
            wkj[k][j] = scan.nextDouble();                   // Takes in inputs for the Wkj weights
         }
         
      } // for (int k = 0; k < numInputNodes; k++)
      
      for (int j = 0; j < numHiddenNodes; j++)
      {
         
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            wji[j][ii] = scan.nextDouble();                  // Loops through and saves all the Wji weights
         }
         
      } // for (int j = 0; j < numHiddenNodes; j++)
      
   } // public static void loadWeights()

   /**
    * Saves the weights for the network to a .txt file.
    * It first saves the weights connecting the input layer to the hidden layer.
    * After, it saves the weights connecting the hidden layer to output layer.
    * Performs an error check to ensure weights are transfered properly to a file.
    */
   public static void saveWeights()
   {
      try
      {
         FileWriter fill = new FileWriter(weightPathway);
         
         for (int k = 0; k < numInputNodes; k++)
         {
            
            for (int j = 0; j < numHiddenNodes; j++)
            {
               fill.write(wkj[k][j] + " ");                // Fills weights to .txt file               
            }
            
         }    
         
         for (int j = 0; j < numHiddenNodes; j++)
         {
            
            for (int ii = 0; ii < numOutputNodes; ii++)
            {
               fill.write(wji[j][ii]+ " ");                // Fills Wji weights to .txt file 
            }
            
         }
        
         fill.close();
      } // try 
      catch (IOException error)
      {
         error.printStackTrace();
      } // try...catch
   } // public static void saveWeights()
  
   /**
    * Sets the values for the truth table and expected outputs to train the network on.
    * The .txt file must follow the proper format for values to transfer correctly
    */
   public static void fillTruthTableTraining() throws Exception
   {
      Scanner controlScan = new Scanner(controlFile); 
      controlScan.nextBoolean();                           // Skips through network parameters to get to truth table
      controlScan.nextDouble(); 
      controlScan.nextDouble(); 
   
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      
      controlScan.nextInt();
      
      controlScan.nextDouble();
      controlScan.nextInt();
      controlScan.nextDouble();
      controlScan.nextInt();
      
      for (int trainC = 0; trainC < numTrainingCases; trainC++)  
      {
         
         for (int k = 0; k < numInputNodes; k++)
         {
            truthTable[trainC][k] = controlScan.nextDouble();           // Saves truth table values
         }        
         
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            t[trainC][ii] = controlScan.nextDouble();                   // Saves expected values to train on
         }   
         
      } // for (int trainC = 0; trainC < numTrainingCases; trainC++)
   } // public static void fillTruthTableTraining()
   
   /**
    * Sets the values for the truth table the network runs on.
    */
   public static void fillTruthTableRunning() throws Exception
   {
      Scanner controlScan = new Scanner(controlFile); 
      controlScan.nextBoolean();                           // Skips through network parameters to get to truth table
      controlScan.nextDouble(); 
      controlScan.nextDouble(); 
   
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      
      controlScan.nextInt();
      
      controlScan.nextDouble();
      controlScan.nextInt();
      controlScan.nextDouble();
      controlScan.nextInt();
      
      for (int trainC = 0; trainC < numTrainingCases; trainC++)
      {
         
         for (int k = 0; k < numInputNodes; k++)
         {
            truthTable[trainC][k] = controlScan.nextDouble();              // Saves truth table values
         } 
         
      } // for (int trainC = 0; trainC < numTrainingCases; trainC++)
   } // public static void fillTruthTableRunning() 

   /**
    * Randomly generates a value based on a preset range.
    * Returns the randomly generated double.
    */
   public static double randomValue()
   {
      return (double)(Math.random() * (randomHigh - randomLow)) + randomLow;    
   }
   
   /**
    * If the training variable is true, it will run and train the feedforward A-B-C Network.
    * Backpropagation will be used and the training will stop if an error threshold or maximum iteration is met.
    * If training, it also saves training time.
    * If training is false, it will find the output based on predetermined weights.
    */
   public static void trainOrRun() throws Exception
   {
      if (!training) 
      {
         
         for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
         {
            findNetworkOutputRunning(numTraining);                 // Running the network on inputed weights
         }
         
      } // if (!training) 
      else
      {
         startTime = System.currentTimeMillis();    // Starts stopwatch timer
         
         System.out.println("------------------------------------------");
         System.out.println("Training Network: ");

         currentAverageError = errorThreshold + errorThreshold;                                  // Ensures the loop is entered
         
         while (currentAverageError > errorThreshold && iterationsReached < maxIterations)       // Determines if another round of backpropagation needs to be found
         {
            for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)             // Loops through each training case
            {
               findNetworkOutputTraining(numTraining);
               trainNetwork(numTraining); 
               
            } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
             
            if (iterationsReached % printIterationNum == 0.0)  // Prints the current average error and iteration after every specified number of iterations
            {
               System.out.println();    
               System.out.println("   Error: " + currentAverageError );
               System.out.println("   Training Iteration: " + iterationsReached);
            }
           
            findNetworkAverageError();  
            iterationsReached++;  
         
         } // while (currentError > errorThreshold && iterationsReached < maxIterations) 
         
         endTime = System.currentTimeMillis();   // Ends stopwatch timer
         totalTime = endTime - startTime;     
      } // if (!training)... else 
      saveWeights();
   } // public static void trainOrRun()
   
   /**
    * Finds the deltaW for the wji, weights connecting the hidden layer to the output layer.
    * Requires saved values from when running through the network.
    * Needs the training case number to find the expected output value it needs to compare to
    */
   public static void trainNetwork(int ti)
   {
      for (int j = 0; j < numHiddenNodes; j++)
      {
         upperCaseOmegaJ = 0.0;    // Zeros the variable
         
         for (int ii = 0; ii <numOutputNodes; ii++)
         {
            upperCaseOmegaJ += psiI[ii] * wji[j][ii]; 
            deltaWji[j][ii] = lambda * h[j] * psiI[ii];  // Calculate the deltawji
            wji[j][ii] += deltaWji[j][ii];               // Apply the detalwji

         } // for (int ii = 0; ii <numOutputNodes; ii++)
         
         upperCasePsiJ = upperCaseOmegaJ * activationFunctionDeriv(thetaj[j]);    // Saves for Wkj
         
         for (int k = 0; k < numInputNodes; k++)
         {
            
            deltaWkj[k][j] = lambda * a[k] * upperCasePsiJ;  // Calculates deltaWkj
            wkj[k][j] += deltaWkj[k][j];                     // Applies deltaWkj

         } // for (int k = 0; k < numInputNodes; k++)
         
      } // for (int j = 0; j < numHiddenNodes; j++
      
   } // public static void trainNetwork(int ti)

   /**
    * Runs through each test case to find the total error and average error for the network 
    */
   public static void findNetworkAverageError()
   {
      totalError = 0.0; 
      
      for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      {
         findNetworkOutputRunning(numTraining);
        
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            totalError += lowerCaseOmega[numTraining][ii] * lowerCaseOmega[numTraining][ii]; 
         }  
         
      } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      
      totalError *= 0.5;
      currentAverageError = totalError / (double) numTrainingCases;
   }// public static void findNetworkAverageError()
   
   
   /**
     * Takes in a test case to find the proper inputs. Then, solves the hidden layer values and output value.
     * Solves using feedforward passage. 
     */
   public static void findNetworkOutputRunning(int testCase)
   {
      for (int k = 0; k < numInputNodes; k++)    // Set up
      {
         a[k] = truthTable[testCase][k];         // fills in input layer Ak
      }
      
      for (int j = 0; j < numHiddenNodes; j++)
      {
         thetaJ = 0.0;                           // Reset
   
         for (int k = 0; k < numInputNodes; k++)
         {
            thetaJ += wkj[k][j] * a[k];          // Calculate thetaJ
         }  
         
         h[j] = activationFunction(thetaJ);      // Finds and fills in the hj layer     
      } // for (int j = 0; j < numHiddenNodes; j++)

      for (int ii = 0; ii < numOutputNodes; ii++)
      {
         thetaI = 0.0; 
         
         for (int j = 0; j < numHiddenNodes; j++)
         {
            thetaI += wji[j][ii] * h[j]; 
         }
         
         f[ii] = activationFunction(thetaI);           // Calculate the output value
      } // for (int ii = 0; ii < numOutputNodes; ii++)
   } // public static void findNetworkOutputRunning(int testCase)
   
   /**
    * Takes in a test case to find the proper inputs. Then, solves the hidden layer values and output value.
    * Saves the values to be used in backpropagation.
    */
   public static void findNetworkOutputTraining(int testCase)
   {
      for (int k = 0; k < numInputNodes; k++)            // Set up
      {
         a[k] = truthTable[testCase][k];                 // Fills in input layer Ak
         
      }
     
      for (int j = 0; j < numHiddenNodes; j++)
      {
         thetaj[j] = 0.0;                                // Reset
   
         for (int k = 0; k < numInputNodes; k++)
         {
            thetaj[j] += a[k] * wkj[k][j];               // Calculate thetaj
         }   
         
         h[j] = activationFunction(thetaj[j]);           // Finds and fills in the hj layer     
      } // for (int j = 0; j < numHiddenNodes; j++)

      for (int ii = 0; ii < numOutputNodes; ii++)
      {
         thetai[ii] = 0.0; 
         
         for (int j = 0; j < numHiddenNodes; j++)
         {
            thetai[ii] += h[j] * wji[j][ii]; 
         }
         
         f[ii] = activationFunction(thetai[ii]);         // Calculate the output value

         lowerCaseOmega[testCase][ii] = t[testCase][ii] - f[ii];       // Saves for average error calculation
         psiI[ii] = lowerCaseOmega[testCase][ii] * activationFunctionDeriv(thetai[ii]);
      } // for (int ii = 0; ii < numOutputNodes; ii++)
   } // public static void findNetworkOutputTraining(int testCase)


   /**
    * Passes the input, x, through the selected threshold function and returns the computed double to the network
    */
   public static double activationFunction(double x)
   {
      return sigmoidFunction(x);
   }
   
   /**
    * Runs the sigmoid function if selected as the activation function 
    * Passes the parameter x through the fuction and returns the double output value
    */
   public static double sigmoidFunction(double x)
   {
      return 1.0 / (1.0 + Math.exp(-x));
   }

   
   /**
    * Passes the input through the derivative of the selected activation function   
    * Passes the parameter x through the fuction and returns the double for the network
    */
   public static double activationFunctionDeriv(double x)
   {
      return sigmoidDeriv(x);
   } 
   
   /**
    * Stores the function for the sigmoid derivative to be used for activationFunctionDeriv
    * Passes the paramter x through the function and returns the double to be used in error analysis.
    */
   public static double sigmoidDeriv(double x)
   {
      double activationFunctionResult = activationFunction(x);
      return activationFunctionResult * (1.0 - activationFunctionResult);
   }
    
      
   /**
    * Prints out a truth table with output values found by the A-B-C network 
    * If training, provides explanation as to why training stopped with end error, iteration count, and time taken to train. 
    * Calls to save current weights to .txt file.
    */
   public static void reportResults() throws Exception
   {
      System.out.println("--------------------------------------------------------------------");
      System.out.println("Reporting Results:");
      System.out.println();
        
      if (training)
      {
         System.out.println("   Training Exit Information:");              
         
         if (currentAverageError <= errorThreshold)                                         // Determines if stopped by reaching the error threshold
         {
            System.out.println("      Stopped because network reached error threshold");
         }
         
         if (iterationsReached >= maxIterations)                                     // Determines if stopped by reaching the max iterations
         {
            System.out.println("      Stopped because network reached max iterations");
         }
         
         System.out.println();
         System.out.println("   Total Error Reached: " + currentAverageError); 
         System.out.println("   Total iterations reached: " + iterationsReached);
         System.out.println("   Total time to train (ms): " + totalTime);
      } // if (training)
      
      System.out.println();
      System.out.println("    ------------------");
      
      for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      {
         System.out.print("    |");
         for (int k = 0 ; k < numInputNodes; k++)
         {
            System.out.print(" " + truthTable[numTraining][k] + " |");    // Prints out the truth table
            findNetworkOutputRunning(numTraining);                                                    
         }
        
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            System.out.print("F" + ii + ": " + f[ii] + "    ");                  // Prints out the output values
         }
                                       
         System.out.println();              
      } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)

      System.out.println("    --------------------");
      saveWeights();
   } // public static void reportResults()
   
   /**
    * Reading from a .txt file, the program starts by setting variables and allocating proper space. 
    * Then, continues by populating the arrays. 
    * The network either runs or trains using backpropagation based on a set variable.
    * A report is then given summarizing the run. 
    */
   public static void main(String[] args) throws Exception
   {
      configParams();
      echoConfigParams();
      allocateMemory();
      populateArrays();
      trainOrRun();
      reportResults();
   } // public static void main(String[] args)
} // public class abcBackpropagation 

