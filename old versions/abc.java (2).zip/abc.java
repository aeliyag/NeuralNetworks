import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.Math;
/**
 * Builds an A-B-C Network to solve problems like OR, AND, and XOR.
 * Can run based of inputed weights from a .txt file or train with random weights
 * It uses gradient descent minimization to train the model. 
 * 1) It configures the parameters and variables to set the structure, mode, and values of the network
 * 2) Prints out the parameters for the user to see what it received
 * 3) Allocates proper memory for arrays depending on if running or training 
 * 4) Fills in the arrays of the truth table and weights depending on testing or running and training type.
 * The network runs feedforward. From an input layer to a hidden layer to an output layer
 * 5) If running, it will find output value. If training, use gradient descent to find error minimized output value
 * 6) Report the output results 
 *  
 * @author Aeliya Grover
 * @version September 21 2023
 */
public class abc 
{
   private static boolean training;
   
   private static String filePathway, fileName;
   
   private static double randomLow, randomHigh;

   private static int  numInputNodes, numHiddenNodes, numOutputNodes, numTrainingCases;
   private static int  numHiddenWeights, numOutputWeights;
   private static int  maxIterations, iterationsReached, printIterationNum;
   
   private static double[] thetaj, thetai;
   private static double[] a, h, f;     
      
   private static double lambda, errorThreshold, totalError, currentAverageError, partialDeriv;
   private static double lowerCaseOmega, upperCasePsiJ, upperCaseOmegaJ;
   private static double thetaJ, thetaI;
   private static double[] psiI; 
   
   private static double[][] truthTable, wkj, wji, deltaWkj, deltaWji, t;
   
   /**
    * Sets variables to help construct the A-B-C structure and mode
    */
   public static void configParams()
   {
      training = true; 
      
      randomLow = 0.1; 
      randomHigh = 1.5; 
   
      numInputNodes = 3; 
      numHiddenNodes = 1; 
      numOutputNodes = 3; 
      
      numTrainingCases = 4;
      iterationsReached = 0;

      numHiddenWeights = numHiddenNodes * numInputNodes; 
      numOutputWeights = numHiddenNodes;

      lambda = 0.3;
      maxIterations = 100000;
      errorThreshold = 0.0002;
      printIterationNum = 10000;
      
      filePathway = "/Users/24aeliyag/Desktop/Programming Projects/Neural Networks/weights.txt";
      fileName = "weights.txt";
   } // public static void configParams()
   
   /**
    * Prints out the variables to user to inform of network configuration.
    * If training, it also outputs training parameters
    */
   public static void echoConfigParams()
   {
      System.out.println("---------------------------------------------------------");
      System.out.println("ECHOING CONFIGURATION PARAMETERS");
      System.out.println();
      System.out.println("    Network Configuration = " + numInputNodes + "-" + numHiddenNodes + "-" + numOutputNodes); 
     
      if (training)     // Only if training:
      {
         System.out.println("    Runtime Trainng Parameters: ");                                                                           
         System.out.println("        Random number range: (" + randomLow + "," + randomHigh + ")");         
         System.out.println("        Max iterations: " + maxIterations);                           
         System.out.println("        Error threshold: " + errorThreshold);                              
         System.out.println("        Lambda value: " + lambda);                               
        
      } // if (training) 
   } // public static void echoConfigParams()
   
   
   /**
    * Defining and dimensioning arrays dependent on whether the program is training or running
    */
   public static void allocateMemory()
   {
      a = new double[numInputNodes];
      h = new double[numHiddenNodes];
      f = new double[numOutputNodes];


      truthTable = new double[numTrainingCases][numInputNodes];

      wkj = new double[numInputNodes][numHiddenNodes];
      wji = new double[numHiddenNodes][numOutputNodes];

      if (training)
      {
         deltaWkj = new double[numInputNodes][numHiddenNodes];
         deltaWji = new double[numHiddenNodes][numOutputNodes];
         t = new double[numTrainingCases][numOutputNodes];
         psiI = new double[numOutputNodes];
         thetaj = new double[numHiddenNodes];
         thetai = new double[numOutputNodes];
      } // if (training)
   
   } // public static void allocateMemory()
   
   /**
    * Assigns values for necessary arrays dependent on if training or running. 
    * Fills in the truth table arrays with proper values for inputs. 
    * If the network is training, it will find random weight values and fill the expected outputs.
    * If the network is running, it requires weight values from the user through a .txt file. 
    */
   public static void populateArrays() throws Exception
   { 
      fillTruthTable();
      
      if (training)                               // Fills in the weights dependent on training mode
      {
         fillExpectedOutputs();
         fillTrainingWeights();
      } // if (training)
      else
      {
         loadWeights();
      } // if (training)... else
   } // public static void populateArrays()
  
   /*
    * Generates weights using a random number generator to start training the network
    */
   public static void fillTrainingWeights()
   {
      for (int k = 0; k < numInputNodes; k++)                   
      {
         for (int j = 0; j < numHiddenNodes; j++)
         {
            wkj[k][j] = randomValue();         // Randomly generate values for Wkj weights
         }
      }
      
      for (int j = 0; j < numHiddenNodes; j++)
      {
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            wji[j][ii] = randomValue();           // Randomly generate values for Wji weights  
         }
                  
      } 
   } // public static void fillTrainingWeights(
   
   /*
    * Sets the weights for the network by reading a txt file
    * The txt is required to first fill in the weights that connect the input layer to hidden layer
    * It will then fill the weights that connect the hidden layer to the output layer. 
    * 
    */
   public static void loadWeights() throws Exception
   {
      File file = new File (filePathway); 
      Scanner scan = new Scanner(file); 
      for (int k = 0; k < numInputNodes; k++)
      {
         for (int j = 0; j < numHiddenNodes; j++)
         {
            wkj[k][j] = scan.nextDouble();                                  // Takes in inputs for the Wkj weights
         }
      }
    
      for (int j = 0; j < numHiddenNodes; j++)
      {
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            wji[j][ii] = scan.nextDouble(); 
         }
      } 
   } // public static void fillRunningWeights() throws Exception
   
   
   /**
    * Saves the weights for the network to a .txt file.
    * It first saves the weights connecting the input layer to the hidden layer.
    * After, it saves the weights connecting the hidden layer to output layer.
    * 
    */
   public static void saveWeights()
   {
      try
      {
         FileWriter fill = new FileWriter(fileName);
         for (int k = 0; k < numInputNodes; k++)
         {
            for (int j = 0; j < numHiddenNodes; j++)
            {
               fill.write(wkj[k][j] + " ");                              
            }
         }     
         for (int j = 0; j < numHiddenNodes; j++)
         {
            for (int ii = 0; ii < numOutputNodes; ii++)
            {
               fill.write(wji[j][ii]+ " "); 
            }
         }
         fill.close();
      } //  try 
      catch (IOException error)
      {
         error.printStackTrace();
      } // try...catch
   }
  
   /**
    * Sets the outputs to train the network on.
    */
   public static void fillExpectedOutputs()
   {

      t[0][0] = 0.0; 
      t[1][0] = 0.0; 
      t[2][0] = 0.0; 
      t[3][0] = 1.0; 
      
      t[0][1] = 0.0; 
      t[1][1] = 1.0; 
      t[2][1] = 1.0; 
      t[3][1] = 1.0; 
     
      t[0][2] = 0.0;
      t[1][2] = 1.0;
      t[2][2] = 1.0;
      t[3][2] = 0.0;
   } // public static void fillExpectedOutputs()

   /**
    * Assigns the input values in the truth tables.
    */
   public static void fillTruthTable()
   {
      truthTable[0][0] = 0.0; 
      truthTable[0][1] = 0.0; 
      truthTable[0][2] = 0.0; 

      truthTable[1][0] = 0.0; 
      truthTable[1][1] = 1.0;
      truthTable[1][2] = 0.0; 
      
      truthTable[2][0] = 1.0; 
      truthTable[2][1] = 0.0; 
      truthTable[2][2] = 0.0; 
      
      truthTable[3][0] = 1.0; 
      truthTable[3][1] = 1.0; 
      truthTable[3][2] = 0.0; 
   } // public static void fillTruthTable()
   

   /**
    * Randomly generates a value based on a preset range
    * @return randomly generated number
    */
   public static double randomValue()
   {
      return (double)(Math.random() * (randomHigh - randomLow)) + randomLow;    
   }
   
   /**
    * If the training variable is true, it will run and train the  feedforward A-B-C Network.
    * Gradient descent minimization will be used and the training will stop if an error threshold or maximum iteration is met.
    * If training is false, it will find the output based on predetermined weights.
    */
   public static void trainOrRun()
   {
      if (!training) 
      {
         for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
         {
            findNetworkOutputRunning(numTraining);                 // Running the network on inputed weights
         }
      } // if (!training) 
      else
      {
         System.out.println("------------------------------------------");
         System.out.println("Training Network: ");
         findNetworkAverageError();    
         
         while (currentAverageError > errorThreshold && iterationsReached < maxIterations)       // Determines if another round of gradient descent needs to be found
         {
            for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)             // Loops through each training case
            {
               findNetworkOutputTraining(numTraining);
               
               calcDeltaWOuputLayer(numTraining);                   // Finds the deltaWji
               calcDeltaWHiddenLayer();                             // Finds the deltaWjk
              
               addDeltaW();                                         // Adds the deltaWs to the weights              
            } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
            if (iterationsReached % printIterationNum == 0.0)
            {
               System.out.println();    
               System.out.println("   Error: " + currentAverageError );
               System.out.println("   Training Iteration: " + iterationsReached);
            }
            findNetworkAverageError();  
            iterationsReached++;  
         } // while (currentError > errorThreshold && iterationsReached < maxIterations) 
      } // if (!training)... else 
   } // public static void trainOrRun()
   
   /**
    * Finds the deltaW for the wji, weights connecting the hidden layer to the output layer.
    * Requires saved thetaI from frindNetworkOutputTraining
    * Needs the training case number to find the expected output value it needs to compare to
    */
   public static void calcDeltaWOuputLayer(int ti)
   {
      for (int ii = 0; ii < numOutputNodes; ii++)
      {
         lowerCaseOmega = t[ti][ii] - f[ii];
         psiI[ii] = lowerCaseOmega * activationFunctionDeriv(thetai[ii]);
         for (int j = 0; j < numHiddenNodes; j++)
         {
            partialDeriv = -h[j] * psiI[ii]; 
            deltaWji[j][ii] = -lambda * partialDeriv;
         } 
      } // for (int ii = 0; ii < numOutputNodes; ii++)
   } // public static void calcDeltaWOuputLayer(int ti)
   
   /**
    * Finds the deltaW for the wkj, weights connecting the input to hidden layer.
    * Requires saved values for PsiI from the calculation in the calcDeltaOutputLayer
    * Requires thetaJ from findNetworkOutputTraining
    * Needs the training case number to find the expected output value it needs to compare to
    */
   public static void calcDeltaWHiddenLayer()
   {
      for (int j = 0; j < numHiddenNodes; j++) 
      {
         upperCaseOmegaJ = 0.0;  
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            upperCaseOmegaJ += psiI[ii] * wji[j][ii];
         }
         
         upperCasePsiJ = upperCaseOmegaJ * activationFunctionDeriv(thetaj[j]);
         for (int k = 0; k < numInputNodes; k++)
         {
            partialDeriv = -a[k] * upperCasePsiJ;
            deltaWkj[k][j] = -lambda * partialDeriv;   
         }
      } // for (int j = 0; j < numHiddenNodes; j++) 
     
   } // public static void calcDeltaWHiddenLayer()
   
   /**
    * Adds saved delta weight values to the current weights for wkj and wji
    */
   public static void addDeltaW()
   {
      for (int k = 0; k < numInputNodes; k++)
      {
         for (int j = 0; j < numHiddenNodes; j++)
         {
            wkj[k][j] += deltaWkj[k][j];          // adding deltaWjk for weights connecting the input and hidden layer
         }
      }
   
      for (int j = 0; j < numHiddenNodes; j++)
      {
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            wji[j][ii] += deltaWji[j][ii];        // adding deltaWji for weights connecting the hidden and output layer
         }
                                                 
      }  
   } // public static void addDeltaW()
   
   /**
    * Runs through each test case to find the total error and average error for the network 
    */
   public static void findNetworkAverageError()
   {
      totalError = 0.0; 
      
      for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      {
         findNetworkOutputRunning(numTraining);
         
         lowerCaseOmega = 0.0;
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            lowerCaseOmega += t[numTraining][ii] - f[ii];
            totalError += lowerCaseOmega * lowerCaseOmega;
         }  
      } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      
      totalError *= 0.5;
      currentAverageError = totalError / (double) numTrainingCases;
   } // public static void findNetworkError()
   
   
   /**
     * Takes in a test case to find the proper inputs. Then, solves the hidden layer values and output value.
     * Solves using feedforward passage. 
     */
   public static void findNetworkOutputRunning(int testCase)
   {
      for (int k = 0; k < numInputNodes; k++)
      {
         a[k] = truthTable[testCase][k];         // fills in input layer Ak
      }
      
      for (int j = 0; j < numHiddenNodes; j++)
      {
         thetaJ = 0.0;                           // Reset
   
         for (int k = 0; k < numInputNodes; k++)
         {
            thetaJ += wkj[k][j] * a[k];          // Calculate thetaj
         }   
         
         h[j] = activationFunction(thetaJ);      // Finds and fills in the hj layer     
      } // for (int j = 0; j < numHiddenNodes; j++)

      for (int ii = 0; ii < numOutputNodes; ii++)
      {
         thetaI = 0.0; 
         
         for (int j = 0; j < numHiddenNodes; j++)
         {
            thetaI += wji[j][ii] * h[j]; 
         }
         
         f[ii] = activationFunction(thetaI);           // Calculate the output value
      } // for (int ii = 0; ii < numOutputNodes; ii++)
   } // public static void findNetWorkOutput(int testCase)
   
   /**
    * Takes in a test case to find the proper inputs. Then, solves the hidden layer values and output value.
    * Saves the theta values to be used in the gradient descent minimization and calculatig delta W
    */
   public static void findNetworkOutputTraining(int testCase)
   {
      for (int k = 0; k < numInputNodes; k++)
      {
         a[k] = truthTable[testCase][k];                 // Fills in input layer Ak
      }
     
      for (int j = 0; j < numHiddenNodes; j++)
      {
         thetaj[j] = 0.0;                                // Reset
   
         for (int k = 0; k < numInputNodes; k++)
         {
            thetaj[j] += wkj[k][j] * a[k];               // Calculate thetaj
         }   
         
         h[j] = activationFunction(thetaj[j]);           // Finds and fills in the hj layer     
      } // for (int j = 0; j < numHiddenNodes; j++)

      for (int ii = 0; ii < numOutputNodes; ii++)
      {
         thetai[ii] = 0.0; 
         
         for (int j = 0; j < numHiddenNodes; j++)
         {
            thetai[ii] += wji[j][ii] * h[j]; 
         }
         
         f[ii] = activationFunction(thetai[ii]);         // Calculate the output value
      } // for (int ii = 0; ii < numOutputNodes; ii++)
   } // public static void findNetWorkOutput(int testCase)

   /**
    * Passes the input through the selected threshold function
    * @param x what will be passed through the function
    * @return  output of the function
    */
   public static double activationFunction(double x)
   {
      return sigmoidFunction(x);
   }
   
   /**
    * Runs the sigmoid function if selected as the activation function 
    * @param x  the input
    * @return  solved output
    */
   public static double sigmoidFunction(double x)
   {
      return 1.0 / (1.0 + Math.exp(-x));
   }

   
   /**
    * Passes the input through the derivative of the selected activation function   
    * @param x  the input
    * @return  solved output
    */
   public static double activationFunctionDeriv(double x)
   {
      return sigmoidDeriv(x);
   } 
   
   /**
    * Stores the function for the sigmoid derivative to be used for activationFunctionDeriv
    * @param x  the input
    * @return  solved output
    */
   public static double sigmoidDeriv(double x)
   {
      double activationFunctionResult = activationFunction(x);
      return activationFunctionResult * (1.0 - activationFunctionResult);
   }
    
      
   /**
    * Prints out a truth table with output values found by the A-B-C network 
    * If training, provides explanation as to why training stopped with end
    * error and iteration count. 
    */
   public static void reportResults()
   {
      System.out.println("--------------------------------------------------------------------");
      System.out.println("Reporting Results:");
      System.out.println();
        
      if (training)
      {
         System.out.println("   Training Exit Information:");              
         if (currentAverageError <= errorThreshold)                                         // Determines if stopped by reaching the error threshold
         {
            System.out.println("      Stopped because network reached error threshold");
         }
         if (iterationsReached >= maxIterations)                                     // Determines if stopped by reaching the max iterations
         {
            System.out.println("      Stopped because network reached max iterations");
         }
            
         System.out.println();
         System.out.println("   Total Error Reached: " + currentAverageError); 
         System.out.println("   Total iterations reached: "+ iterationsReached);
      } // if (training)
      
      System.out.println();
      System.out.println("    ------------------");
      
      for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      {
         System.out.print("    |");
         for (int k = 0 ; k < numInputNodes; k++)
         {
            System.out.print(" " + truthTable[numTraining][k] + " |");    // Prints out the truth table
            findNetworkOutputRunning(numTraining);                                                    
         }
        
         for (int ii = 0; ii < numOutputNodes; ii++)
         {
            System.out.print("F" + ii + ": " + f[ii] + "    ");                  // Prints out the output values
         }
                                       
         System.out.println();              
      } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)

      System.out.println("    --------------------");
   } // public static void reportResults()
   
   
   /**
    * Starts by setting variables and allocating proper space. Then, continues by populating the arrays. 
    * The network either runs or trains based on a set variable and the reports are output either at
    * the end of running or until a cuttoff has been passed for training. 
    */
   public static void main(String[] args) throws Exception
   {
      configParams();
      echoConfigParams();
      allocateMemory();
      populateArrays();
      trainOrRun();
      reportResults();
   } // public static void main(String[] args) 
   
} // public class abc 
