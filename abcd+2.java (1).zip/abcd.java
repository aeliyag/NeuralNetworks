import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.Math;
/**
 * Builds an A-B-C-D Network to solve problems like OR, AND, and XOR.
 * Can run based of set configurations from a .txt file or train with random weights
 * It uses backpropagation to train the model. 
 * 1) It configures the parameters and variables to set the structure, mode, and values of the network
 * 2) Prints out the parameters for the user to see what it received
 * 3) Allocates proper memory for arrays depending on if running or training 
 * 4) Fills in the arrays of the truth table and weights depending on testing or running and training type.
 * The network runs feedforward. From an input layer to a hidden layer to an output layer
 * 5) If running, it will find output value. If training, it will time the process and use backpropagation to train the network.
 * 6) Report the output results and saves the weights.
 *  
 *  
 *  Method Headers:
 *      public static void configParams(String fileName)
 *      public static void readControlFile()
 *      public static void echoConfigParams()
 *      public static void allocateMemory()
 *      public static void populateArrays()
 *      public static void fillTrainingWeights()
 *      public static void loadWeights()
 *      public static void saveWeights()
 *      public static void fillTruthTableTraining()
 *      public static void fillTruthTableRunning()
 *      public static double randomValue()
 *      public static void trainOrRun()
 *      public static void trainNetwork(int ti)
 *      public static void findNetworkAverageError()
 *      public static void findNetworkOutputRunning(int testCase)
 *      public static void findNetworkOutputTraining(int testCase)
 *      public static double activationFunction(double x)
 *      public static double sigmoidFunction(double x)
 *      public static double activationFunctionDeriv(double x)
 *      public static double sigmoidDeriv(double x)
 *      public static void reportResults()
 *      public static void main(String[] args)
 *      
 *  
 * @author Aeliya Grover
 * @version October 25 2023
 */
public class abcd
{
   private static boolean training, override;
   
   private static String weightPathway, filePathway, controlFilePathway;
   
   private static double randomLow, randomHigh;

   private static int  nm, nk, nj, numTrainingCases, ni;
   private static int  numHiddenWeights;
   private static int  maxIterations, iterationsReached, printIterationNum;
   
   private static double[] thetak, thetaj, upperCasePsiJ;
   private static double[] am, ak, aj, ai;     
      
   private static double lambda, errorThreshold, totalError, currentAverageError, partialDeriv;
   private static double  upperCaseOmegaJ, upperCaseOmegaK;
   private static double thetaK, thetaJ, thetaI, upperCasePsiK;
   private static double[] lowerCasePsiI; 
   
   private static double[][] lowerCaseOmega, truthTable, wmk, wkj, wji, t;
   
   private static double startTime, endTime, totalTime;

   private static File controlFile; 

   /**
    * Sets variables to help construct the A-B-C-D structure, parameters, and mode
    */
   public static void configParams(String fileName) throws Exception
   {   
      controlFilePathway = "/Users/24aeliyag/Desktop/NeuralNetworks/ControlFile.txt";  //default

      System.out.println("file name:" + fileName);
      
      if (fileName.length() > 0)
      {
         controlFilePathway = fileName;
      }
      
      controlFile = new File (controlFilePathway);
      
      readControlFile();    
      iterationsReached = 0;
   } // public static void configParams(String fileName)
   
   /**
    * Uses values from the control file to fill in network structure, parameter, and mode.
    * Finds weight file pathway
    * The .txt file must match up to the specific format in order for values to be transfered correctly.
    */
   public static void readControlFile() throws Exception 
   {
      Scanner controlScan = new Scanner(controlFile); 
      
      weightPathway = controlScan.nextLine();
      System.out.println(weightPathway);
      
      training = controlScan.nextBoolean();
      randomLow = controlScan.nextDouble(); 
      randomHigh = controlScan.nextDouble(); 
   
      
      nm = controlScan.nextInt();
      nk = controlScan.nextInt();
      nj = controlScan.nextInt(); 
      ni = controlScan.nextInt(); 
      
      numTrainingCases = controlScan.nextInt();
      
      lambda = controlScan.nextDouble();
      maxIterations = controlScan.nextInt();
      errorThreshold = controlScan.nextDouble();
      printIterationNum = controlScan.nextInt();
      
   } // public static void readControlFile()
   
   /**
    * Prints out the variables to user, informing of network configuration.
    * If training, it also outputs training parameters
    */
   public static void echoConfigParams()
   {
      System.out.println("---------------------------------------------------------");
      System.out.println("ECHOING CONFIGURATION PARAMETERS");
      System.out.println();
      System.out.println("    Network Configuration = " + nm + "-" + nk + "-" + nj + "-" + ni); 
     
      if (training)    // Only if training:
      {
         System.out.println("    Runtime Trainng Parameters: ");                                                                           
         System.out.println("        Random number range: (" + randomLow + "," + randomHigh + ")");         
         System.out.println("        Max iterations: " + maxIterations);                           
         System.out.println("        Error threshold: " + errorThreshold);                              
         System.out.println("        Lambda value: " + lambda);                               
        
      } // if (training) 
   } // public static void echoConfigParams()
   
   /**
    * Defining and dimensioning arrays dependent on whether the program is training or running
    */
   public static void allocateMemory()
   {
      am = new double[nm];
      ak = new double[nk];
      aj = new double[nj];
      ai = new double[ni];


      truthTable = new double[numTrainingCases][nm];

      wmk = new double[nm][nk];
      wkj = new double[nk][nj];
      wji = new double[nj][ni];

      if (training)
      {
         t = new double[numTrainingCases][ni];               //expected output
         lowerCaseOmega = new double[numTrainingCases][ni];
         lowerCasePsiI = new double[ni];
         upperCasePsiJ = new double[nj];
         thetak = new double[nk];
         thetaj = new double[nj];
      } // if (training)
   } // public static void allocateMemory()
   
   /**
    * Assigns values for necessary arrays dependent on if training or running. 
    * Fills in the truth table arrays with proper values for inputs. If training, fills out the expected outputs.
    * If the network is training, it will find random weight values and fill the expected outputs.
    * If the network is running, it requires weight values from the user through a .txt file. 
    */
   public static void populateArrays() throws Exception
   { 
      if (training)                               // Fills in the weights dependent on training mode
      {
         fillTruthTableTraining();
         fillTrainingWeights();
      } // if (training)
      else
      {
         fillTruthTableRunning();
         loadWeights();
      } // if (training)... else
   } // public static void populateArrays()
  
   /*
    * Generates weights using a random number generator to start training the network.
    */
   public static void fillTrainingWeights()
   {
      for (int m = 0; m < nm; m++)
      {
         
         for (int k = 0; k < nk; k++)
         {
            wmk[m][k] = randomValue(); 
         }
         
      }
      
      for (int k = 0; k < nk; k++)                   
      {
        
         for (int j = 0; j < nj; j++)
         {
            wkj[k][j] = randomValue();       // Randomly generate values for Wkj weights
         }
         
      } // for (int k = 0; k < numInputNodes; k++)  
      
      for (int j = 0; j < nj; j++)
      {
        
         for (int ii = 0; ii < ni; ii++)
         {
            wji[j][ii] = randomValue();      // Randomly generate values for Wji weights  
         }
         
      } 
      
   } // public static void fillTrainingWeights()
   
   /*
    * Sets the weights for the network by reading a txt file. 
    * The .txt is required to first fill in the weights that connect the input layer to hidden layer.
    * The order of the weights file must be constant to match the method.
    * It will then fill the weights that connect the hidden layer to the output layer. 
    */
   public static void loadWeights() throws Exception
   {
      File file = new File(weightPathway); 
      Scanner scan = new Scanner(file); 
      
      for (int m = 0; m < nm; m++)
      {
         
         for (int k = 0; k < nk; k++)
         {
            wmk[m][k] = scan.nextDouble();  
         }
         
      }
      
      for (int k = 0; k < nk; k++)
      {
         
         for (int j = 0; j < nj; j++)
         {
            wkj[k][j] = scan.nextDouble();                   // Takes in inputs for the Wkj weights
         }
         
      } // for (int k = 0; k < numInputNodes; k++)
      
      for (int j = 0; j < nj; j++)
      {
         
         for (int ii = 0; ii < ni; ii++)
         {
            wji[j][ii] = scan.nextDouble(); 
         }
         
      } 
      
   } // public static void loadWeights()

   /**
    * Saves the weights for the network to a .txt file.
    * It first saves the weights connecting the input layer to the hidden layer.
    * After, it saves the weights connecting the hidden layer to output layer.
    */
   public static void saveWeights()
   {
      try
      {
         FileWriter fill = new FileWriter(weightPathway);
        
         for (int m = 0; m < nm; m++)
         {
            
            for (int k = 0; k < nk; k++)
            {
               fill.write(wmk[m][k] + " ");
            }
            
         }
         
         for (int k = 0; k < nk; k++)
         {
            
            for (int j = 0; j < nj; j++)
            {
               fill.write(wkj[k][j] + " ");                // Fills weights to .txt file               
            }
            
         }    
         
         for (int j = 0; j < nj; j++)
         {
            
            for (int ii = 0; ii < ni; ii++)
            {
               fill.write(wji[j][ii]+ " "); 
            }
            
         }
         fill.close();
      } // try 
      catch (IOException error)
      {
         error.printStackTrace();
      } // try...catch
   } // public static void saveWeights()
  
   /**
    * Sets the values for the truth table and expected outputs to train the network on.
    * The .txt file must follow the proper format for values to transfer correctly
    */
   public static void fillTruthTableTraining() throws Exception
   {
      Scanner controlScan = new Scanner(controlFile); 
      
      controlScan.nextLine();
      
      controlScan.nextBoolean();                           // Skips through network parameters to get to truth table
      controlScan.nextDouble(); 
      controlScan.nextDouble(); 
   
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      controlScan.nextInt();

      controlScan.nextInt();
      
      controlScan.nextDouble();
      controlScan.nextInt();
      controlScan.nextDouble();
      controlScan.nextInt();

      
      
      for (int trainC = 0; trainC < numTrainingCases; trainC++)  
      {
         
         for (int m = 0; m < nm; m++)
         {
            truthTable[trainC][m] = controlScan.nextDouble();           // Saves truth table values
         }        
         
         for (int ii = 0; ii < ni; ii++)
         {
            t[trainC][ii] = controlScan.nextDouble();                   // Saves expected values to train on
         }   
         
      } // for (int trainC = 0; trainC < numTrainingCases; trainC++)
   } // public static void fillTruthTableTraining()
   
   /**
    * Sets the values for the truth table the network runs on.
    */
   public static void fillTruthTableRunning() throws Exception
   {
      Scanner controlScan = new Scanner(controlFile); 
      
      controlScan.nextLine();
      controlScan.nextBoolean();                           // Skips through network parameters to get to truth table
      controlScan.nextDouble(); 
      controlScan.nextDouble(); 
   
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      controlScan.nextInt(); 
      controlScan.nextInt();
      
      controlScan.nextInt();
      
      controlScan.nextDouble();
      controlScan.nextInt();
      controlScan.nextDouble();
      controlScan.nextInt();
      
      for (int trainC = 0; trainC < numTrainingCases; trainC++)
      {
         
         for (int m = 0; m < nm; m++)
         {
            truthTable[trainC][m] = controlScan.nextDouble();              // Saves truth table values
         } 
         
      } // for (int trainC = 0; trainC < numTrainingCases; trainC++)
   } // public static void fillTruthTableRunning() 

   /**
    * Randomly generates a value based on a preset range.
    * Returns the randomly generated value.
    */
   public static double randomValue()
   {
      return (double)(Math.random() * (randomHigh - randomLow)) + randomLow;    
   }
   
   /**
    * If the training variable is true, it will run and train the feedforward A-B-C-D Network.
    * Backpropagation will be used and the training will stop if an error threshold or maximum iteration is met.
    * If training, it also saves training time.
    * If training is false, it will find the output based on predetermined weights.
    */
   public static void trainOrRun() throws Exception
   {
      if (!training) 
      {
         
         for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
         {
            findNetworkOutputRunning(numTraining);                 // Running the network on inputed weights
         }
         
      } // if (!training) 
      else
      {
         startTime = System.currentTimeMillis();
         System.out.println("------------------------------------------");
         System.out.println("Training Network: ");
         currentAverageError = errorThreshold + errorThreshold;
         while (currentAverageError > errorThreshold && iterationsReached < maxIterations)       // Determines if another round of backpropagation needs to be found
         {
            for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)             // Loops through each training case
            {
               findNetworkOutputTraining(numTraining);
               trainNetwork(numTraining);     
            } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
             
            if (iterationsReached % printIterationNum == 0.0)
            {
               System.out.println();    
               System.out.println("   Error: " + currentAverageError );
               System.out.println("   Training Iteration: " + iterationsReached);
            }
            findNetworkAverageError();  
            iterationsReached++;  
         } // while (currentError > errorThreshold && iterationsReached < maxIterations) 
         
         endTime = System.currentTimeMillis();
         totalTime = endTime - startTime;
      } // if (!training)... else 
      saveWeights();
   } // public static void trainOrRun()
   
   /**
    * Finds the deltaW for the wji, weights connecting the hidden layer to the output layer.
    * Requires saved values from when running through the network.
    * Needs the training case number to find the expected output value it needs to compare to
    */
   public static void trainNetwork(int ti)
   {
      for (int j = 0; j < nj; j++)
      {
         upperCaseOmegaJ = 0.0;
         
         for (int ii = 0; ii < ni; ii++)
         {
            upperCaseOmegaJ += lowerCasePsiI[ii] * wji[j][ii];
            wji[j][ii] += lambda * aj[j] * lowerCasePsiI[ii];
         }
         
         upperCasePsiJ[j] = upperCaseOmegaJ * activationFunctionDeriv(thetaj[j]);
      } //  for (int j = 0; j < nj; j++)
      
      for (int k = 0; k < nk; k++)
      {
         upperCaseOmegaK = 0.0; 
         
         for (int j = 0; j < nj; j++)
         {
            upperCaseOmegaK += upperCasePsiJ[j] * wkj[k][j];
            wkj[k][j] += lambda * ak[k] * upperCasePsiJ[j];
         }
         
         upperCasePsiK = upperCaseOmegaK * activationFunctionDeriv(thetak[k]);
         
         for (int m = 0; m < nm; m++)
         {
            wmk[m][k] += lambda * am[m] * upperCasePsiK;
         }
         
      } // for (int k = 0; k < nk; k++)
      
   } // public static void trainNetwork(int ti)

   /**
    * Runs through each test case to find the total error and average error for the network 
    */
   public static void findNetworkAverageError()
   {
         totalError = 0.0; 
         
         for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
         {
            findNetworkOutputRunning(numTraining);
           

            for (int ii = 0; ii < ni; ii++)
            {
              
               totalError += lowerCaseOmega[numTraining][ii] * lowerCaseOmega[numTraining][ii]; 
            }  

         } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
         
         totalError *= 0.5;
         currentAverageError = totalError / (double) numTrainingCases;
   }// public static void findNetworkAverageError()
   
   
   /**
     * Takes in a test case to find the proper inputs. Then, solves the hidden layer values and output value.
     * Solves using feedforward passage. 
     */
   public static void findNetworkOutputRunning(int testCase)
   {
      for (int m = 0; m < nm; m++)    // Set up
      {
         am[m] = truthTable[testCase][m];         // fills in input layer Ak
      }
      
      for (int k = 0; k < nk; k++)
      {
         thetaK = 0.0;
         
         for (int m = 0; m < nm; m++)
         {
            thetaK += am[m] * wmk[m][k];
         }
         
         ak[k] = activationFunction(thetaK);

      } // for (int k = 0; k < nk; k++)
      
      for (int j = 0; j < nj; j++)
      {
         thetaJ = 0.0;
         
         for (int k = 0; k < nk; k++)
         {
            thetaJ += ak[k] * wkj[k][j]; 
         }
         
         aj[j] = activationFunction(thetaJ);
         
      } // for (int j = 0; j < nj; j++)
      
      for (int ii = 0; ii < ni; ii++)
      {
         thetaI = 0.0;
         
         for (int j = 0; j < nj; j++)
         {
            thetaI += aj[j] * wji[j][ii];
         }
         ai[ii] = activationFunction(thetaI);
         
      } // for (int ii = 0; ii < ni; ii++)

   } // public static void findNetworkOutputRunning(int testCase)
   
   /**
    * Takes in a test case to find the proper inputs. Then, solves the hidden layer values and output value.
    * Saves the values to be used in backpropagation.
    */
   public static void findNetworkOutputTraining(int testCase)
   {
      for (int m = 0; m < nm; m++)    // Set up
      {
         am[m] = truthTable[testCase][m];         // fills in input layer Ak
      }
      
      for (int k = 0; k < nk; k++)
      {
         thetak[k] = 0.0;
         
         for (int m = 0; m < nm; m++)
         {
            thetak[k] += am[m] * wmk[m][k];
         }
         
         ak[k] = activationFunction(thetak[k]);

      } // for (int k = 0; k < nk; k++)
      
      for (int j = 0; j < nj; j++)
      {
         thetaj[j] = 0.0;
         
         for (int k = 0; k < nk; k++)
         {
            thetaj[j] += ak[k] * wkj[k][j]; 
         }
         
         aj[j] = activationFunction(thetaj[j]);
      }
      
      for (int ii = 0; ii < ni; ii++)
      {
         thetaI = 0.0;
         
         for (int j = 0; j < nj; j++)
         {
            thetaI += aj[j] * wji[j][ii];
         }
         
         ai[ii] = activationFunction(thetaI);
         lowerCaseOmega[testCase][ii] = t[testCase][ii] - ai[ii];
         lowerCasePsiI[ii] = lowerCaseOmega[testCase][ii] * activationFunctionDeriv(thetaI);
         
      } // for (int ii = 0; ii < ni; ii++)
   } // public static void findNetworkOutputTraining(int testCase)


   /**
    * Passes the input, x, through the selected threshold function and returns the computed value to the network
    */
   public static double activationFunction(double x)
   {
      return sigmoidFunction(x);
   }
   
   /**
    * Runs the sigmoid function if selected as the activation function 
    * Passes the parameter x through the function and returns the output value
    */
   public static double sigmoidFunction(double x)
   {
      return 1.0 / (1.0 + Math.exp(-x));
   }

   
   /**
    * Passes the input through the derivative of the selected activation function   
    * Passes the parameter x through the function and returns it for the network
    */
   public static double activationFunctionDeriv(double x)
   {
      return sigmoidDeriv(x);
   } 
   
   /**
    * Stores the function for the sigmoid derivative to be used for activationFunctionDeriv
    * Passes the paramter x through the function and returns it to be used in error analysis.
    */
   public static double sigmoidDeriv(double x)
   {
      double activationFunctionResult = activationFunction(x);
      return activationFunctionResult * (1.0 - activationFunctionResult);
   }
    
      
   /**
    * Prints out a truth table with output values found by the A-B-C-D network 
    * If training, provides explanation as to why training stopped with end error, iteration count, and time taken to train. 
    * Calls to save current weights to .txt file.
    */
   public static void reportResults() throws Exception
   {
      System.out.println("--------------------------------------------------------------------");
      System.out.println("Reporting Results:");
      System.out.println();
        
      if (training)
      {
         System.out.println("   Training Exit Information:");              
         
         if (currentAverageError <= errorThreshold)                                         // Determines if stopped by reaching the error threshold
         {
            System.out.println("      Stopped because network reached error threshold");
         }
         
         if (iterationsReached >= maxIterations)                                     // Determines if stopped by reaching the max iterations
         {
            System.out.println("      Stopped because network reached max iterations");
         }
         
         System.out.println();
         System.out.println("   Total Error Reached: " + currentAverageError); 
         System.out.println("   Total iterations reached: " + iterationsReached);
         System.out.println("   Total time to train (ms): " + totalTime);
      } // if (training)
      
      System.out.println();
      System.out.println("    ------------------");
      
      for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)
      {
         System.out.print("    |");
         for (int m = 0 ; m < nm; m++)
         {
            System.out.print(" " + truthTable[numTraining][m] + " |");    // Prints out the truth table
            findNetworkOutputRunning(numTraining);   
         }
        
         for (int ii = 0; ii < ni; ii++)
         {
            System.out.print("F" + ii + ": " + ai[ii] + "    ");                  // Prints out the output values
         }
                                       
         System.out.println();              
      } // for (int numTraining = 0; numTraining < numTrainingCases; numTraining++)

      System.out.println("    --------------------");
      saveWeights();
   } // public static void reportResults()
   
   /**
    * Reading from a .txt file, the program starts by setting variables and allocating proper space. 
    * Then, continues by populating the arrays. 
    * The network either runs or trains using backpropagation based on a set variable.
    * A report is then given summarizing the run. 
    */
   public static void main(String[] args) throws Exception
   {      
      if (args.length > 0)
      {
         configParams(args[0]);
      }
      else
      {
         configParams("");
      }

      echoConfigParams();
      allocateMemory();
      populateArrays();
      trainOrRun();
      reportResults();
   } // public static void main(String[] args)
} // public class abcd
